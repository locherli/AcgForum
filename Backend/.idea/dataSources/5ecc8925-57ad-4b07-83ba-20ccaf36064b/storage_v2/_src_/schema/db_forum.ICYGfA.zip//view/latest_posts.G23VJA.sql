create definer = root@`%` view latest_posts as
select `db_forum`.`post`.`id`         AS `id`,
       `db_forum`.`post`.`authorId`   AS `authorId`,
       `db_forum`.`post`.`isRoot`     AS `isRoot`,
       `db_forum`.`post`.`root`       AS `root`,
       `db_forum`.`post`.`title`      AS `title`,
       `db_forum`.`post`.`date`       AS `date`,
       `db_forum`.`post`.`likeNum`    AS `likeNum`,
       `db_forum`.`post`.`commentNum` AS `commentNum`,
       `db_forum`.`post`.`content`    AS `content`
from `db_forum`.`post`
where (`db_forum`.`post`.`isRoot` = 1)
order by `db_forum`.`post`.`date` desc;

