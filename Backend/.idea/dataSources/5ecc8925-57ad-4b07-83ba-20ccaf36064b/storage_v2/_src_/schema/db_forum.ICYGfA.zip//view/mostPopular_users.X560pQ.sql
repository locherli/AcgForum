create definer = root@`%` view mostPopular_users as
select `db_forum`.`user_info`.`id`               AS `id`,
       `db_forum`.`user_info`.`userName`         AS `userName`,
       `db_forum`.`user_info`.`email`            AS `email`,
       `db_forum`.`user_info`.`phoneNum`         AS `phoneNum`,
       `db_forum`.`user_info`.`hc_password`      AS `hc_password`,
       `db_forum`.`user_info`.`gender`           AS `gender`,
       `db_forum`.`user_info`.`age`              AS `age`,
       count(`db_forum`.`ref_self_fan`.`id_fan`) AS `fan_number`
from (`db_forum`.`ref_self_fan` left join `db_forum`.`user_info`
      on ((`db_forum`.`user_info`.`id` = `db_forum`.`ref_self_fan`.`id`)))
group by `db_forum`.`user_info`.`id`
order by `fan_number` desc;

